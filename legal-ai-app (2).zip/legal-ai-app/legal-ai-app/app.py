"""AI 법률 분석 웹사이트 - Streamlit 진입점. 실행: streamlit run app.py"""
import streamlit as st

from src.analyzer import analyze_case
from src.config import GEMINI_API_KEY, LAW_API_OC
from src.gemini_client import GeminiError
from src.law_api import LawApiError

st.set_page_config(page_title="AI 법률 분석", page_icon="⚖️", layout="wide")

st.title("⚖️ AI 법률 분석")
st.caption("사건 상황을 입력하면 관련 법률과 유사 판례를 찾아 쉽게 정리해 드립니다.")

with st.sidebar:
    st.header("설정")
    top_n = st.slider("법령·판례 검색 개수", 1, 5, 3)
    st.markdown("---")
    st.markdown(
        "**데이터 출처**: 국가법령정보센터 Open API  \n"
        "**AI**: Google Gemini API"
    )
    if not GEMINI_API_KEY or not LAW_API_OC:
        st.warning(".env 에 GEMINI_API_KEY, LAW_API_OC 를 설정해 주세요.")

situation = st.text_area(
    "사건 상황을 자세히 적어 주세요",
    height=200,
    placeholder="예) 전세 계약이 끝났는데 집주인이 보증금을 돌려주지 않고 있습니다...",
)

if st.button("분석하기", type="primary", disabled=not situation.strip()):
    status = st.status("분석 중...", expanded=True)
    try:
        result = analyze_case(
            situation.strip(), top_n=top_n, progress=lambda m: status.write(m)
        )
        status.update(label="분석 완료", state="complete", expanded=False)
    except (GeminiError, LawApiError) as e:
        status.update(label="오류 발생", state="error")
        st.error(str(e))
        st.stop()

    st.markdown(result.report)

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("📜 검색된 법령")
        for law in result.laws:
            st.markdown(f"- [{law['name']}]({law['link']}) · {law['ministry']}")
        if not result.laws:
            st.write("검색 결과가 없습니다.")
    with col2:
        st.subheader("🏛️ 검색된 판례")
        for p in result.precedents:
            st.markdown(f"- [{p['case_no']} {p['case_name']}]({p['link']}) · {p['court']}")
        if not result.precedents:
            st.write("검색 결과가 없습니다.")

st.divider()
st.caption("본 서비스는 법률 자문이 아닌 참고용 정보 제공 서비스입니다.")
