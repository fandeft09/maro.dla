# AI 법률 분석 웹사이트

사건 상황을 입력하면 국가법령정보센터의 법령·판례 공개 API로 관련 자료를 찾고,
Gemini API가 핵심 내용을 분석·정리해 주는 Streamlit 앱입니다.

## 폴더 구조
```
legal-ai-app/
├─ app.py                 # Streamlit 화면
├─ src/
│  ├─ config.py           # 환경변수 로딩
│  ├─ law_api.py          # 국가법령정보센터 API (법령·판례)
│  ├─ gemini_client.py    # Gemini API 래퍼
│  └─ analyzer.py         # 키워드 추출 → 검색 → AI 분석 파이프라인
├─ .streamlit/config.toml # 테마
├─ .vscode/               # VS Code 설정·디버그 구성
├─ requirements.txt
└─ .env.example
```

## 시작하기
1. API 키 준비
   - Gemini: https://aistudio.google.com 에서 API 키 발급
   - 국가법령정보센터: https://open.law.go.kr 에서 Open API 신청 후 OC 값 확인
2. 가상환경과 패키지 설치 (VS Code 터미널)
   ```bash
   python -m venv .venv
   source .venv/bin/activate        # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```
3. `.env.example` 을 `.env` 로 복사하고 키 입력
4. 실행
   ```bash
   streamlit run app.py
   ```
   또는 VS Code 의 실행 및 디버그에서 `Streamlit: app.py` 선택

## 동작 흐름
1. 사건 입력 → Gemini가 검색용 법률 키워드 추출
2. 키워드로 법령·판례 검색 (국가법령정보센터 API)
3. 법령 조문과 판례 판시사항·판결요지 수집
4. Gemini가 수집된 자료에 근거해 요약·분석·대응 방향 정리

## 참고
- 법령정보센터 API 응답 필드가 바뀌면 `src/law_api.py` 의 파싱 부분을 조정하세요.
- 배포 시에는 `.env` 대신 Streamlit secrets 에 키를 등록하세요.
- 본 서비스는 법률 자문이 아닌 참고용 정보입니다.
