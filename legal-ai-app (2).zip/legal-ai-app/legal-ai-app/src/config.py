"""환경변수 로딩. .env 또는 Streamlit secrets 중 하나를 사용합니다."""
import os

from dotenv import load_dotenv

load_dotenv()


def get_setting(name: str, default: str = "") -> str:
    value = os.getenv(name)
    if value:
        return value
    try:
        import streamlit as st

        return str(st.secrets.get(name, default))
    except Exception:
        return default


GEMINI_API_KEY = get_setting("GEMINI_API_KEY")
GEMINI_MODEL = get_setting("GEMINI_MODEL", "gemini-2.5-flash")
LAW_API_OC = get_setting("LAW_API_OC")
