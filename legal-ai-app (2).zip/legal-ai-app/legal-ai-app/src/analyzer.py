"""사건 입력 → 키워드 추출 → 법령·판례 검색 → Gemini 분석 파이프라인."""
from __future__ import annotations

from dataclasses import dataclass, field

from . import gemini_client as gm
from . import law_api

KEYWORD_SYSTEM = (
    "당신은 한국 법률 검색 보조자입니다. 사용자의 사건 상황에서 법령·판례 검색에 쓸 "
    '핵심 법률 키워드를 뽑아 JSON으로만 답하세요. 형식: {"law_keywords": [..최대3개], '
    '"precedent_keywords": [..최대3개]}. 키워드는 짧은 법률 용어(예: 임대차보호법, 보증금반환)로.'
)

ANALYSIS_SYSTEM = (
    "당신은 일반인을 돕는 법률 정보 안내자입니다. 제공된 법령·판례 자료에 근거해서만 답하고, "
    "자료에 없는 내용은 추측하지 마세요. 쉬운 한국어로 설명하세요. "
    "마지막에는 이 내용이 법률 자문이 아닌 참고용 정보이며 필요시 변호사 등 전문가나 "
    "대한법률구조공단(132) 상담을 권한다고 안내하세요."
)

ANALYSIS_TEMPLATE = """## 사용자 사건 상황
{situation}

## 검색된 관련 법령
{laws}

## 검색된 유사 판례
{precedents}

위 자료를 바탕으로 아래 형식의 마크다운으로 답하세요.
### 1. 사건 요약
### 2. 관련 법률과 핵심 내용 (법령명·조문 포함)
### 3. 유사 판례 분석 (사건번호, 쟁점, 결론, 내 상황과의 관련성)
### 4. 권장 대응 방향 (단계별)
### 5. 유의사항
"""


@dataclass
class AnalysisResult:
    keywords: dict = field(default_factory=dict)
    laws: list[dict] = field(default_factory=list)
    precedents: list[dict] = field(default_factory=list)
    report: str = ""


def analyze_case(situation: str, top_n: int = 3, progress=None) -> AnalysisResult:
    def step(msg: str):
        if progress:
            progress(msg)

    result = AnalysisResult()

    step("사건에서 법률 키워드를 추출하는 중...")
    result.keywords = gm.generate_json(situation, system=KEYWORD_SYSTEM)

    step("관련 법령을 검색하는 중...")
    seen = set()
    for kw in result.keywords.get("law_keywords", [])[:3]:
        for law in law_api.search_laws(kw, display=top_n):
            if law["id"] not in seen:
                seen.add(law["id"])
                result.laws.append(law)
    result.laws = result.laws[:top_n]

    step("유사 판례를 검색하는 중...")
    seen = set()
    for kw in result.keywords.get("precedent_keywords", [])[:3]:
        for prec in law_api.search_precedents(kw, display=top_n):
            if prec["id"] not in seen:
                seen.add(prec["id"])
                result.precedents.append(prec)
    result.precedents = result.precedents[:top_n]

    step("법령·판례 본문을 불러오는 중...")
    law_ctx = []
    for law in result.laws:
        text = law_api.get_law_text(law["id"])
        law_ctx.append(f"- {law['name']} ({law['ministry']})\n{text}")
    prec_ctx = []
    for prec in result.precedents:
        text = law_api.get_precedent_summary(prec["id"])
        prec_ctx.append(
            f"- {prec['court']} {prec['case_no']} ({prec['date']}) {prec['case_name']}\n{text}"
        )

    step("AI가 내용을 분석·정리하는 중...")
    prompt = ANALYSIS_TEMPLATE.format(
        situation=situation,
        laws="\n\n".join(law_ctx) or "(검색 결과 없음)",
        precedents="\n\n".join(prec_ctx) or "(검색 결과 없음)",
    )
    result.report = gm.generate_text(prompt, system=ANALYSIS_SYSTEM)
    return result
