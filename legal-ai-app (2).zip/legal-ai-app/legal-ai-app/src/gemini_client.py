"""Gemini API 래퍼 (google-genai SDK)."""
from __future__ import annotations
from functools import lru_cache
import json

from google import genai
from google.genai import types

from .config import GEMINI_API_KEY, GEMINI_MODEL


class GeminiError(RuntimeError):
    pass


@lru_cache(maxsize=1)
def _client() -> genai.Client:
    if not GEMINI_API_KEY:
        raise GeminiError("GEMINI_API_KEY 가 설정되지 않았습니다. .env 파일을 확인하세요.")
    return genai.Client(api_key=GEMINI_API_KEY)


def generate_text(prompt: str, system: str = "") -> str:
    try:
        res = _client().models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(system_instruction=system or None),
        )
        return res.text or ""
    except Exception as e:
        raise GeminiError(f"Gemini 호출 실패: {e}") from e


def generate_json(prompt: str, system: str = "") -> dict:
    try:
        res = _client().models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=system or None,
                response_mime_type="application/json",
            ),
        )
        return json.loads(res.text or "{}")
    except Exception as e:
        raise GeminiError(f"Gemini JSON 응답 처리 실패: {e}") from e
