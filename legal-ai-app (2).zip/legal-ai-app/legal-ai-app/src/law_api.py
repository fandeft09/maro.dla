"""국가법령정보센터 Open API 클라이언트 (법령·판례 검색 및 본문 조회).

API 안내: https://open.law.go.kr
- 검색: http://www.law.go.kr/DRF/lawSearch.do
- 본문: http://www.law.go.kr/DRF/lawService.do
응답 필드명은 API 버전에 따라 달라질 수 있어 방어적으로 파싱합니다.
"""
from __future__ import annotations

import requests

from .config import LAW_API_OC

SEARCH_URL = "http://www.law.go.kr/DRF/lawSearch.do"
SERVICE_URL = "http://www.law.go.kr/DRF/lawService.do"
TIMEOUT = 15


class LawApiError(RuntimeError):
    pass


def _get(url: str, params: dict) -> dict:
    if not LAW_API_OC:
        raise LawApiError("LAW_API_OC 가 설정되지 않았습니다. .env 파일을 확인하세요.")
    params = {"OC": LAW_API_OC, "type": "JSON", **params}
    try:
        res = requests.get(url, params=params, timeout=TIMEOUT)
        res.raise_for_status()
        return res.json()
    except (requests.RequestException, ValueError) as e:
        raise LawApiError(f"법령정보센터 API 호출 실패: {e}") from e


def _as_list(value) -> list:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def search_laws(query: str, display: int = 5) -> list[dict]:
    """키워드로 법령 검색."""
    data = _get(SEARCH_URL, {"target": "law", "query": query, "display": display})
    items = _as_list(data.get("LawSearch", {}).get("law"))
    return [
        {
            "id": it.get("법령일련번호"),
            "name": it.get("법령명한글"),
            "ministry": it.get("소관부처명"),
            "enforced": it.get("시행일자"),
            "link": _full_link(it.get("법령상세링크")),
        }
        for it in items
    ]


def get_law_text(law_mst: str, max_chars: int = 4000) -> str:
    """법령 본문(조문) 텍스트. 너무 길면 잘라서 반환."""
    data = _get(SERVICE_URL, {"target": "law", "MST": law_mst})
    articles = _as_list(data.get("법령", {}).get("조문", {}).get("조문단위"))
    lines = []
    for a in articles:
        content = a.get("조문내용", "")
        if isinstance(content, list):
            content = " ".join(map(str, content))
        lines.append(str(content).strip())
    return "\n".join(lines)[:max_chars]


def search_precedents(query: str, display: int = 5) -> list[dict]:
    """키워드로 판례 검색."""
    data = _get(SEARCH_URL, {"target": "prec", "query": query, "display": display})
    items = _as_list(data.get("PrecSearch", {}).get("prec"))
    return [
        {
            "id": it.get("판례일련번호"),
            "case_name": it.get("사건명"),
            "case_no": it.get("사건번호"),
            "date": it.get("선고일자"),
            "court": it.get("법원명"),
            "link": _full_link(it.get("판례상세링크")),
        }
        for it in items
    ]


def get_precedent_summary(prec_id: str, max_chars: int = 2500) -> str:
    """판례의 판시사항·판결요지 중심 텍스트."""
    data = _get(SERVICE_URL, {"target": "prec", "ID": prec_id})
    body = data.get("PrecService", {})
    parts = []
    for key in ("판시사항", "판결요지", "참조조문"):
        if body.get(key):
            parts.append(f"[{key}] {body[key]}")
    return "\n".join(parts).replace("<br/>", "\n")[:max_chars]


def _full_link(path: str | None) -> str | None:
    if not path:
        return None
    return path if path.startswith("http") else f"https://www.law.go.kr{path}"
